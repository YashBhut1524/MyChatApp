this project is for sih hackthon smart classroom 
